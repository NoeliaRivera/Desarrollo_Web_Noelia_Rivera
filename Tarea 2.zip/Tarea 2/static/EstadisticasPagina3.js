document.getElementById("boton-actividades").onclick = function() {
    window.location.href = "/registrar";
};

document.getElementById("boton-registro").onclick = function() {
    window.location.href = "/";
};