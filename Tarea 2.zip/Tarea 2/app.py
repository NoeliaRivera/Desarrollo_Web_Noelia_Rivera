from flask import Flask, render_template, request, redirect, url_for
from extensions import db
import os
from collections import Counter

app = Flask(__name__)

app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+pymysql://root:programacionweb@localhost:3306/tarea2"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = os.path.join(os.getcwd(), "uploads")

db.init_app(app)

from models.modelo import Miembro, Actividad, crearMiembro, crearActividad, obtenerComunas, obtenerMiembros, ultimosMiembros

@app.route("/")
def index():
    ultimos = ultimosMiembros()
    return render_template("PortadaPagina1.html", ultimos=ultimos)

@app.route("/registrar", methods=["GET", "POST"])
def registrar():
    if request.method == "POST":
        nombre = request.form.get("usuario")
        correo = request.form.get("correo")
        telefono = request.form.get("telefono")
        comuna_id = request.form.get("comuna")
        tipo_miembro = request.form.get("cargo")
        nuevo_miembro = crearMiembro(
            nombre=nombre,
            email=correo,
            telefono=telefono,
            comuna_id=comuna_id,
            tipo=tipo_miembro)
        actividad_nombre = request.form.get("actividad")
        actividad_tipo = request.form.get("tipo")
        dia = request.form.get("dia")
        hora_inicio = request.form.get("hora_inicio")
        duracion = request.form.get("duracion")
        descripcion = request.form.get("descripcion")
        crearActividad(
            miembro_id=nuevo_miembro.id,
            nombre=actividad_nombre,
            tipo=actividad_tipo,
            dia=dia,
            hora_inicio=hora_inicio,
            duracion=duracion,
            descripcion=descripcion)
        return redirect(url_for("miembros"))
    comunas = obtenerComunas()
    return render_template("RegistroPagina1.html", comunas=comunas)


@app.route("/miembros")
def miembros():
    lista_miembros = obtenerMiembros()
    return render_template("ListadoPagina4.html", miembros=lista_miembros)

from collections import Counter

@app.route("/estadisticas")
def estadisticas():
    miembros = Miembro.query.all()
    actividades = Actividad.query.all()

    pregrado = len([
        m for m in miembros
        if m.tipo and m.tipo.lower() == "pregrado"])

    postgrado = len([
        m for m in miembros
        if m.tipo and m.tipo.lower() == "postgrado"])

    academico = len([
        m for m in miembros
        if m.tipo and m.tipo.lower() == "académico"])

    funcionario = len([
        m for m in miembros
        if m.tipo and m.tipo.lower() == "funcionario"])

    recreativa = len([
        a for a in actividades
        if a.tipo and a.tipo.lower() == "recreación"])

    deportiva = len([
        a for a in actividades
        if a.tipo and a.tipo.lower() == "deporte"])

    tecnologica = len([
        a for a in actividades
        if a.tipo and a.tipo.lower() == "tecnología"])

    cientifica = len([
        a for a in actividades
        if a.tipo and a.tipo.lower() == "arte"])

    otra = len([
        a for a in actividades
        if a.tipo and a.tipo.lower() == "otra"])
    max_actividad = max(recreativa, deportiva, tecnologica, cientifica, otra, 1)
    return render_template("EstadisticasPagina3.html", pregrado=pregrado, postgrado=postgrado, academico=academico, funcionario=funcionario, recreativa=recreativa, deportiva=deportiva, tecnologica=tecnologica, cientifica=cientifica, otra=otra, max_actividad=max_actividad)

if __name__ == "__main__":
    app.run(debug=True)